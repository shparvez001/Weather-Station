<!DOCTYPE html>

<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">


  
  <meta name="viewport" content="width=device-width, initial-scale=1">


<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap-theme.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>


<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

<style type="text/css">

td.one {background: #acfff0; bgcolor="#acfff0";	}

td.two {background: #ffdaa1; bgcolor="#ffdaa1";	}

</style>

<title>Sylhet Weather Data | Beta</title>

</head>

<?php set_include_path("/home/shparvez/public_html/weather/includes"); ?>

<?php include 'menu.php'; ?>
<body >

<br><br><br>


<div class="container-fluid">

<div class="row">



<!--
<?php include 'latest_data.php'; ?>

<h2 style="color: blue; text-align: center;">
			<?php 
			//echo $temperaturex; 
			?></h2>
			-->








<?php include 'config.php'; ?>




<div class="col-xs-12 col-sm-9 col-md-9 col-lg-9">
<div class="jumbotron">
<div class="blog-post">

<h2 style="color: blue; text-align: center;" class="blog-post-title">
			Here are the Latest data measured by our source</h2>


</div>
</div>



<table class="table table-hover">
<tbody>
<tr>
 <td class="one">
<?php echo "<h3> Current Temperature is </h3>";  ?>
 


 

<?php

$tbl_name="temp"; // Table name 
//SET time_zone ='+06:00';
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 

 
<?php


// Start looping rows in mysql database.
for ($i=$num+1; $i>$num; $i--)
{
$rows=mysql_fetch_array($result)
?>


<?php 
$temperature= 460/1024 * $rows['temp'];  //OLD for my project
//$temperature=  $rows['temp'];    //FOr Khaled and Tahmid's Project
$timed = $rows['time'];

 $temperature=round($temperature, 1);

echo  $temperature;
echo " &deg;C ___recorded @ ";
include 'date_extract.php';
echo $orgdate;


//echo " test code  ";

//echo date("h:m:s:", $rows['time']); 






?>



<?php
// close while loop 
}
?>

 </td>
 
 </tr>
 
 <tr>
 <td class="two">


<?php echo "<h3> Current Humidity is </h3>"; ?>
 

 

<?php
// Humidity part



$tbl_name="humidity"; // Table name 

// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 
<?php


// Start looping rows in mysql database.
for ($i=$num+1; $i>$num; $i--)
{
$rows=mysql_fetch_array($result)
?>


<?php 

$rhsense= $rows['hum'];
$k= 5/1024 *$rhsense;
$rh= 4.8008*$k*$k*$k*$k*$k - 47.772*$k*$k*$k*$k + 184.64 *$k*$k*$k -343.78*$k*$k +334.28*$k +- 110.6;

$humidity= $rh; 
$timed = $rows['time'];

 $humidity=round($humidity, 1);

echo  $humidity;
echo " % __recorded @ ";

include 'date_extract.php';
echo $orgdate;

?>



<?php
// close while loop 
}
?>

 </td>
 </tr>
 <tr>
  <td class="one">
 
 
<?php echo "<h3> Current Pressure is </h3>";  ?>
 


 

<?php
// Pressure part



$tbl_name="pressure"; // Table name 

// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 
<?php


// Start looping rows in mysql database.
for ($i=$num+1; $i>$num; $i--)
{
$rows=mysql_fetch_array($result)
?>


<?php 


$timed = $rows['time'];  

echo  round($rows['baro'],1);
echo " Kpa __recorded @ ";

include 'date_extract.php';
echo $orgdate;

?>



<?php
// close while loop 
}
?>

 </td>
 </tr>
 <tr>
 <td class="two">

<?php echo "<h3> Current Wind Speed is </h3>";   ?>
 


 

<?php
// Wind part



$tbl_name="wind"; // Table name 

// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 
<?php


// Start looping rows in mysql database.
for ($i=$num+1; $i>$num; $i--)
{
$rows=mysql_fetch_array($result)
?>

<?php 

$rand=rand(0, 3);
//$speedskmph= $wind*3.14*.27*.25*3.6*1.1 + $rand;
$speedskmph= $wind*3.14*.27*.25*3.6*1.1 ;

$timed = $rows['time'];

echo  round($speedskmph,1);
echo " Km/hr (kmph) __recorded @ ";

include 'date_extract.php';
echo $orgdate;

?>



<?php
// close while loop 
}
?>

 </td>
 </tr>
 <tr>
  <td class="one">

<?php echo "<h3> Current Total rain today till 12 am is </h3>";  ?>


 

<?php
// Wind part



$tbl_name="rain"; // Table name 

// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 
<?php


// Start looping rows in mysql database.
for ($i=$num+1; $i>$num; $i--)
{
$rows=mysql_fetch_array($result)
?>


<?php 



$timed = $rows['time']; 

echo  round($rows['rain'],1);
echo " mm  __recorded @ ";

include 'date_extract.php';
echo $orgdate;

?>



<?php
// close while loop 
}
?>
</td></tr>

</tbody>
</table>


</div>

<div class="col-xs-12 col-sm-3 col-md-3 col-lg-3 sidebar">

<?php include 'time.php'; ?>
<?php include 'sharer.php'; ?>

</div>


</div>



<?php include 'time.php'; ?>

<?php include 'configclose.php'; ?>
<?php include 'footer.php'; ?>


</div>


</body>
</html>