<?php
include("config.php");
$tbl_name="combo"; // Table name 

// Get values from form 
$temp=$_POST['temp'];
$humidity=$_POST['humidity'];

// Insert data into mysql 
$sql="INSERT INTO $tbl_name(temp, humidity) VALUES('$temp, $humidity')";
$result=mysql_query($sql);

// if successfully insert data into database, displays message "Successful". 
if($result){
echo "Successful";
echo "<BR>";
echo "<a href='shparvez.net'>SHP</a>";
}

else {
echo "ERROR";
}
?> 

<?php 
// close connection 
mysql_close();
?>
