<!DOCTYPE html>

<html lang="en-US"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width">
<title>Sylhet Weather Data | Beta</title>



<?php set_include_path("/home/shparvez/public_html/weather/includes"); ?>

<?php include 'config.php'; ?>


<body class="page page-id-573 page-template-default custom-background group-blog">








<p>Last five recorded Temperature Datas</p>


<table width="400" border="1" cellspacing="0" cellpadding="3">

<?php

$tbl_name="temp"; // Table name 
//SET time_zone ='+06:00';
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 

 
<?php


// Start looping rows in mysql database.
for ($i=$num; $i>$num-5; $i--)
{
$rows=mysql_fetch_array($result)
?>

<tr>
<td width="50%">
<?php 
$temperature= 460/1024 * $rows['temp']; 
$timed = $rows['time'];

echo "<h3>Temperature is </h3>";   

echo  $temperature;
echo " °C ___recorded @ ";
include 'date_extract.php';
echo $orgdate;


//echo " test code  ";

//echo date("h:m:s:", $rows['time']); 






?>

</td>


</tr>

<?php
// close while loop 
}
?>
</table>

<p>Last five recorded Humidity Datas</p>


<table width="400" border="1" cellspacing="0" cellpadding="3">

<?php
// Humidity part



$tbl_name="humidity"; // Table name 

// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 
<?php


// Start looping rows in mysql database.
for ($i=$num; $i>$num-5; $i--)
{
$rows=mysql_fetch_array($result)
?>

<tr>
<td width="50%">
<?php 

$rhsense= $rows['hum'];
$k= 5/1024 *$rhsense;
$rh= 4.8008*$k*$k*$k*$k*$k - 47.772*$k*$k*$k*$k + 184.64 *$k*$k*$k -343.78*$k*$k +334.28*$k +- 110.6;

$humidity= $rh; 
$timed = $rows['time'];

echo "<h3>Humidity is </h3>";   

echo  $humidity;
echo " % __recorded @ ";

include 'date_extract.php';
echo $orgdate;

?>

</td>

</tr>

<?php
// close while loop 
}
?>
</table>



<p>Last five recorded Pressure Datas</p>


<table width="400" border="1" cellspacing="0" cellpadding="3">

<?php
// Humidity part



$tbl_name="pressure"; // Table name 

// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 
<?php


// Start looping rows in mysql database.
for ($i=$num; $i>$num-5; $i--)
{
$rows=mysql_fetch_array($result)
?>

<tr>
<td width="50%">
<?php 

//$rhsense= $rows['hum'];
//$k= 5/1024 *$rhsense;
//$rh= 4.8008*$k*$k*$k*$k*$k - 47.772*$k*$k*$k*$k + 184.64 *$k*$k*$k -343.78*$k*$k +334.28*$k +- 110.6;

$humidity= $rh; 
$timed = $rows['time'];

echo "<h3>Pressure is </h3>";   

echo  $rows['baro'];
echo " Kpa __recorded @ ";

include 'date_extract.php';
echo $orgdate;

?>

</td>

</tr>

<?php
// close while loop 
}
?>
</table>



<p>Last five recorded Wind Datas</p>


<table width="400" border="1" cellspacing="0" cellpadding="3">

<?php
// Wind part



$tbl_name="wind"; // Table name 

// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 
<?php


// Start looping rows in mysql database.
for ($i=$num; $i>$num-5; $i--)
{
$rows=mysql_fetch_array($result)
?>

<tr>
<td width="50%">
<?php 

$speedskmph= $wind*3.14*.27*.25*3.6*1.1 + 3;

$timed = $rows['time'];

echo "<h3>Wind Speed is </h3>";   

echo  $speedskmph;
echo " Km/hr (kmph) __recorded @ ";

include 'date_extract.php';
echo $orgdate;

?>

</td>

</tr>

<?php
// close while loop 
}
?>
</table>



<p>Last five recorded Rain Datas</p>


<table width="400" border="1" cellspacing="0" cellpadding="3">

<?php
// Wind part



$tbl_name="rain"; // Table name 

// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 
<?php


// Start looping rows in mysql database.
for ($i=$num; $i>$num-5; $i--)
{
$rows=mysql_fetch_array($result)
?>

<tr>
<td width="50%">
<?php 



$timed = $rows['time'];

echo "<h3>Tatal rain today till 12 am is </h3>";   

echo  $rows['rain'];
echo " mm  __recorded @ ";

include 'date_extract.php';
echo $orgdate;

?>

</td>

</tr>

<?php
// close while loop 
}
?>
</table>

<?php include 'time.php'; ?>

<?php include 'configclose.php'; ?>
<?php include 'footer.php'; ?>

</body>
</html>