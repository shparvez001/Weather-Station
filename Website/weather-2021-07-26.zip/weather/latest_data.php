<?php set_include_path("/home/shparvez/public_html/weather/includes"); ?>

<?php include 'config.php'; ?>


<?php

$tbl_1="temp"; 
$tbl_2="humidity"; 
$tbl_3="pressure"; 
$tbl_4="wind"; 
$tbl_5="rain"; 

$sql_1="SELECT * FROM $tbl_1 ORDER BY id DESC";
$sql_2="SELECT * FROM $tbl_2 ORDER BY id DESC";
$sql_3="SELECT * FROM $tbl_3 ORDER BY id DESC";
$sql_4="SELECT * FROM $tbl_4 ORDER BY id DESC";
$sql_5="SELECT * FROM $tbl_5 ORDER BY id DESC";

//temperature
$res_t=mysql_query($sql_1);
$num_t=mysql_numrows($res_t);
$rows_t=mysql_fetch_array($res_t);
$temperaturex= 460/1024 * $rows_t['temp']; 
$timed_t = $rows_t['time'];


//humidity
$res_h=mysql_query($sql_2);
$num_h=mysql_numrows($res_h);
$rows_h=mysql_fetch_array($res_h);
$humidity= 460/1024 * $rows_h['temp']; 
$timed_h = $rows_h['time'];

?>

<?php include 'configclose.php'; ?>