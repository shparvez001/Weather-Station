<?php
function curPageName() {
 return substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);
}

//echo "The current page name is ".curPageName();
?>

<style type="text/css">
 
#share-buttons img {
width: 35px;
padding: 5px;
border: 0;
box-shadow: 0;
display: inline;
}
 
</style>

<script type="text/javascript">
// Popup window code
function newPopup(url) {
	popupWindow = window.open(
		url,'popUpWindow','height=700,width=800,left=10,top=10,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes')
}
</script>




 <script>
      window.fbAsyncInit = function() {
        FB.init({
          appId      : '770669496319261',
          xfbml      : true,
          version    : 'v2.1'
        });
        
        FB.ui({
     method: 'share_open_graph',
     action_type: 'og.likes',
     
     action_properties: JSON.stringify({
      object:'<?php  echo  curPageURL() ;?>',
      
      
      
     })
    }, function(response){});
    
    
    
    

        
      };

      (function(d, s, id){
         var js, fjs = d.getElementsByTagName(s)[0];
         if (d.getElementById(id)) {return;}
         js = d.createElement(s); js.id = id;
         js.src = "//connect.facebook.net/en_US/sdk.js";
         fjs.parentNode.insertBefore(js, fjs);
       }(document, 'script', 'facebook-jssdk'));
    </script>
    
    
    


<?php
function curPageURL() {
 $pageURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
 return $pageURL;
}

  echo "<br>You are in   " .curPageURL();
  echo "<br> Share this page" ;  
  
  ?>






  <div id="share-buttons">
  
  <div
  class="fb-like"
  data-send="true"
  data-width="50"
  data-show-faces="true">
</div>


 
<!-- Facebook -->
<a href="JavaScript:newPopup('http://www.facebook.com/sharer.php?u=<?php  echo  curPageURL() ;?>');" target="_blank"><img src="http://www.simplesharebuttons.com/images/somacro/facebook.png" alt="Facebook" /></a>
 
<!-- Twitter 2 -->
<a href="JavaScript:newPopup('https://twitter.com/intent/tweet?url=<?php  echo  curPageURL() ;?>&text=Check out Current weather at Sylhet now&hashtags=SylhetWeather&original_referer=http://weather.shparvez.net/');" target="_blank"><img src="http://www.simplesharebuttons.com/images/somacro/twitter.png" alt="Twitter" /></a>

<!-- Twitter 2
<a href="https://twitter.com/intent/tweet?url=<?php  echo  curPageURL() ;?>&text=Check out Current weather at Sylhet now&hashtags=SylhetWeather&original_referer=http://weather.shparvez.net/" target="_blank"><img src="http://www.simplesharebuttons.com/images/somacro/twitter.png" alt="Twitter" /></a>
 -->

<!-- Twitter
<a href="http://twitter.com/share?url=<?php  echo  curPageURL() ;?>  " target="_blank"><img src="http://www.simplesharebuttons.com/images/somacro/twitter.png" alt="Twitter" /></a>
 
  -->
 

<!-- Email -->
<a href="JavaScript:newPopup('mailto:?Subject=Sylhet Weather&Body=Check out Current weather at Sylhet now @ <?php  echo curPageURL();?>');"><img src="http://www.simplesharebuttons.com/images/somacro/email.png" alt="Email" /></a>
 
</div>
   
   