<?php 
// close connection 
mysql_close();
?>