<?php
$host="localhost";
$username="shparvez_001";
$password="23807161";
$db_name="shparvez_weather";


mysql_connect("$host", "$username", "$password")or die("cannot connect to server");
mysql_select_db("$db_name")or die("cannot select db"); 
?>