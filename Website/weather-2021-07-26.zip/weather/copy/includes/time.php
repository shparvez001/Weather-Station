  <?php

// Return date/time info of a timestamp; then format the output

$mydate=getdate(date("U"));
$hours = $mydate[hours]+6;
echo  "<h3>Today is ,$mydate[weekday], $mydate[month] $mydate[mday], $mydate[year]. $hours: $mydate[minutes]: $mydate[seconds]</h3>";
?>