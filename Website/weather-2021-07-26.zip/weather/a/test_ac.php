<?php
include("config.php");
$tbl_name="test"; // Table name 

// Get values from form 
$name=$_POST['text'];

// Insert data into mysql 
$sql="INSERT INTO $tbl_name(text)VALUES('$name')";
$result=mysql_query($sql);

// if successfully insert data into database, displays message "Successful". 
if($result){
echo "Successful";
echo "<BR>";
echo "<a href='shparvez.net'>SHP</a>";
}

else {
echo "ERROR";
}
?> 

<?php 
// close connection 
mysql_close();
?>
