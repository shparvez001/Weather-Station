<?php
include("config.php");
$tbl_name="combo"; // Table name 

// Get values from form 
$temp=$_POST['t'];

// Insert data into mysql 
$sql="INSERT INTO $tbl_name(temp) VALUES('$temp')";
$result=mysql_query($sql);

// if successfully insert data into database, displays message "Successful". 
if($result){
echo "Successful";
echo "<BR>";
echo "<a href='shparvez.net'>SHP</a>";
}

else {
echo "ERROR";
}
?> 

<?php 
// close connection 
mysql_close();
?>
