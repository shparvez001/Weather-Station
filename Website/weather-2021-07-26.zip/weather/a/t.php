<?php
include("config.php");
$tbl_name="temp"; // Table name 

// Get values from form 
$name=$_POST['t'];
//Normally it is HHTP post for my original GSM module and nodeMCU but changing to GET to test for Khaled adn Tahmid's project
//$name=$_GET['t'];



// Insert data into mysql 
$sql="INSERT INTO $tbl_name(temp)VALUES('$name')";
$result=mysql_query($sql);

// if successfully insert data into database, displays message "Successful". 
if($result){
echo "Successful";
echo $name;
echo "<BR>";
echo "<a href='shparvez.net'>SHP</a>";
}

else {
echo "ERROR";
}
?> 

<?php 
// close connection 
mysql_close();
?>
