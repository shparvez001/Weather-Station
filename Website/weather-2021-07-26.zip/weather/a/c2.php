<html>

<body>

<form action="c1.php"" method="POST">

 

Name: <input type="text" name="x" id="x" />


 

<input type="submit" />

</form>

</body>

</html>