<html>

<body>

<form action="test_ac.php"" method="POST">

 

Name: <input type="text" name="text" id="text" />


 

<input type="submit" />

</form>

</body>

</html>