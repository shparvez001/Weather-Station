<?php
include("config.php");
$tbl_name="combo"; // Table name 

$string = $_POST['x']; 
//$temp=450;
//$humidity=950;

$string2 = str_replace(",", " ", $string) ;
$words = explode(" ", $string2);




// Get values from form 
$temp=$words[0];
$humidity=$words[1];
$wind=$words[2];
$rain=$words[3];
$pressure=$words[4];

// Insert data into mysql 
$sql="INSERT INTO $tbl_name(temp, humidity, wind, rain, pressure) VALUES('$temp', '$humidity','$wind','$rain','$pressure')";
$result=mysql_query($sql);

// if successfully insert data into database, displays message "Successful". 
if($result){
echo "Successful";
echo "<BR>";
echo "<a href='shparvez.net'>SHP</a>";
}

else {
echo "ERROR";
}
?> 

<?php 
// close connection 
mysql_close();
?>
