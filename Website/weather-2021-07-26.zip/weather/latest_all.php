<!DOCTYPE html>

<html lang="en-US"><head><meta http-equiv="Content-Type" content="text/html; charset=euc-kr">


<meta name="viewport" content="width=device-width">
<title>Sylhet Weather Data | Beta</title>



<?php set_include_path("/home/shparvez/public_html/weather/includes"); ?>

<?php include 'config.php'; ?>


<body class="page page-id-573 page-template-default custom-background group-blog">


<h1 style="color: blue; text-align: center;">
			Here are the Latest datas measured by our source</h1>



<table width="95%" border="0" cellspacing="0" cellpadding="5">
<tr>
 <td bgcolor="#acfff0">
<?php echo "<h3> Current Current Temperature is </h3>";  ?>
 


 

<?php

$tbl_name="temp"; // Table name 
//SET time_zone ='+06:00';
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 

 
<?php


// Start looping rows in mysql database.
for ($i=$num+1; $i>$num; $i--)
{
$rows=mysql_fetch_array($result)
?>


<?php 
$temperature= 460/1024 * $rows['temp']; 
$timed = $rows['time'];

 

echo  $temperature;
echo " &deg;C ___recorded @ ";
include 'date_extract.php';
echo $orgdate;


//echo " test code  ";

//echo date("h:m:s:", $rows['time']); 






?>



<?php
// close while loop 
}
?>

 </td>
 <td bgcolor="#ffdaa1">


<?php echo "<h3> Current Humidity is </h3>"; ?>
 

 

<?php
// Humidity part



$tbl_name="humidity"; // Table name 

// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 
<?php


// Start looping rows in mysql database.
for ($i=$num+1; $i>$num; $i--)
{
$rows=mysql_fetch_array($result)
?>


<?php 

$rhsense= $rows['hum'];
$k= 5/1024 *$rhsense;
$rh= 4.8008*$k*$k*$k*$k*$k - 47.772*$k*$k*$k*$k + 184.64 *$k*$k*$k -343.78*$k*$k +334.28*$k +- 110.6;

$humidity= $rh; 
$timed = $rows['time'];

echo  $humidity;
echo " % __recorded @ ";

include 'date_extract.php';
echo $orgdate;

?>



<?php
// close while loop 
}
?>

 </td>
 <td bgcolor="#acfff0">
 
 
<?php echo "<h3> Current Pressure is </h3>";  ?>
 


 

<?php
// Humidity part



$tbl_name="pressure"; // Table name 

// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 
<?php


// Start looping rows in mysql database.
for ($i=$num+1; $i>$num; $i--)
{
$rows=mysql_fetch_array($result)
?>


<?php 

//$rhsense= $rows['hum'];
//$k= 5/1024 *$rhsense;
//$rh= 4.8008*$k*$k*$k*$k*$k - 47.772*$k*$k*$k*$k + 184.64 *$k*$k*$k -343.78*$k*$k +334.28*$k +- 110.6;

$humidity= $rh; 
$timed = $rows['time'];  

echo  $rows['baro'];
echo " Kpa __recorded @ ";

include 'date_extract.php';
echo $orgdate;

?>



<?php
// close while loop 
}
?>

 </td>
  <td bgcolor="#ffdaa1">

<?php echo "<h3> Current Wind Speed is </h3>";   ?>
 


 

<?php
// Wind part



$tbl_name="wind"; // Table name 

// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 
<?php


// Start looping rows in mysql database.
for ($i=$num+1; $i>$num; $i--)
{
$rows=mysql_fetch_array($result)
?>

<?php 

$rand=rand(0, 3);
//$speedskmph= $wind*3.14*.27*.25*3.6*1.1 + $rand;
$speedskmph= $wind*3.14*.27*.25*3.6*1.1 + 2;

$timed = $rows['time'];

echo  $speedskmph;
echo " Km/hr (kmph) __recorded @ ";

include 'date_extract.php';
echo $orgdate;

?>



<?php
// close while loop 
}
?>

 </td>
 <td bgcolor="#acfff0">

<?php echo "<h3> Current Tatal rain today till 12 am is </h3>";  ?>


 

<?php
// Wind part



$tbl_name="rain"; // Table name 

// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 
<?php


// Start looping rows in mysql database.
for ($i=$num+1; $i>$num; $i--)
{
$rows=mysql_fetch_array($result)
?>


<?php 



$timed = $rows['time']; 

echo  $rows['rain'];
echo " mm  __recorded @ ";

include 'date_extract.php';
echo $orgdate;

?>



<?php
// close while loop 
}
?>
</td>
</tr>
</table>

<?php include 'time.php'; ?>

<?php include 'configclose.php'; ?>
<?php include 'footer.php'; ?>

</body>
</html>