<!DOCTYPE html>

<html lang="en">
<head>
<?php set_include_path("/home/shparvez/public_html/weather/includes"); ?>
<?php include 'head.php'; ?>
<?php include 'menu.php'; ?>

    <!--Load the AJAX API-->
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript">
    
      // Load the Visualization API and the piechart package.
      google.load('visualization', '1.0', {'packages':['corechart']});
      
      // Set a callback to run when the Google Visualization API is loaded.
      google.setOnLoadCallback(drawChart);

      // Callback that creates and populates a data table, 
      // instantiates the pie chart, passes in the data and
      // draws it.
      function drawChart() {

      // Create the data table.
      var data = new google.visualization.DataTable();
      data.addColumn('string', 'Topping');
      data.addColumn('number', 'Slices');
      data.addRows([
        ['Mushrooms', 3],
        ['Onions', 1],
        ['Olives', 1], 
        ['Zucchini', 1],
        ['Pepperoni', 2]
      ]);

      // Set chart options
      var options = {'title':'How Much Pizza I Ate Last Night',
                     'width':400,
                     'height':300};

      // Instantiate and draw our chart, passing in some options.
      var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
      chart.draw(data, options);
    }
    </script>
    
 <title>Sylhet Weather Data | Beta</title>   
    
  </head>

  <body>
  
  <br><br><br>


<div class="container-fluid">

<div class="row">
  



<?php include 'config.php'; ?>




<div class="col-xs-12 col-sm-9 col-md-9 col-lg-9">
<div class="jumbotron">
<div class="blog-post">

<h2 style="color: blue; text-align: center;" class="blog-post-title">
			This page is still to be created</h2>

</div>
</div>



<table class="table table-hover">
<tbody>
<tr>
 <td class="one">
<?php echo "<h3> Current Temperature is </h3>";  ?>
 


 

<?php

$tbl_name="temp"; // Table name 
//SET time_zone ='+06:00';
// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 

 
<?php


// Start looping rows in mysql database.
for ($i=$num+1; $i>$num; $i--)
{
$rows=mysql_fetch_array($result)
?>


<?php 
$temperature= 460/1024 * $rows['temp']; 
$timed = $rows['time'];

 $temperature=round($temperature, 1);

echo  $temperature;
echo " &deg;C ___recorded @ ";
include 'date_extract.php';
echo $orgdate;


//echo " test code  ";

//echo date("h:m:s:", $rows['time']); 






?>



<?php
// close while loop 
}
?>

 </td>
 
 </tr>
 
 <tr>
 <td class="two">


<?php echo "<h3> Current Humidity is </h3>"; ?>
 

 

<?php
// Humidity part



$tbl_name="humidity"; // Table name 

// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 
<?php


// Start looping rows in mysql database.
for ($i=$num+1; $i>$num; $i--)
{
$rows=mysql_fetch_array($result)
?>


<?php 

$rhsense= $rows['hum'];
$k= 5/1024 *$rhsense;
$rh= 4.8008*$k*$k*$k*$k*$k - 47.772*$k*$k*$k*$k + 184.64 *$k*$k*$k -343.78*$k*$k +334.28*$k +- 110.6;

$humidity= $rh; 
$timed = $rows['time'];

 $humidity=round($humidity, 1);

echo  $humidity;
echo " % __recorded @ ";

include 'date_extract.php';
echo $orgdate;

?>



<?php
// close while loop 
}
?>

 </td>
 </tr>
 <tr>
  <td class="one">
 
 
<?php echo "<h3> Current Pressure is </h3>";  ?>
 


 

<?php
// Pressure part



$tbl_name="pressure"; // Table name 

// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 
<?php


// Start looping rows in mysql database.
for ($i=$num+1; $i>$num; $i--)
{
$rows=mysql_fetch_array($result)
?>


<?php 


$timed = $rows['time'];  

echo  round($rows['baro'],1);
echo " Kpa __recorded @ ";

include 'date_extract.php';
echo $orgdate;

?>



<?php
// close while loop 
}
?>

 </td>
 </tr>
 <tr>
 <td class="two">

<?php echo "<h3> Current Wind Speed is </h3>";   ?>
 


 

<?php
// Wind part



$tbl_name="wind"; // Table name 

// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 
<?php


// Start looping rows in mysql database.
for ($i=$num+1; $i>$num; $i--)
{
$rows=mysql_fetch_array($result)
?>

<?php 

$rand=rand(0, 3);
//$speedskmph= $wind*3.14*.27*.25*3.6*1.1 + $rand;
$speedskmph= $wind*3.14*.27*.25*3.6*1.1 ;

$timed = $rows['time'];

echo  round($speedskmph,1);
echo " Km/hr (kmph) __recorded @ ";

include 'date_extract.php';
echo $orgdate;

?>



<?php
// close while loop 
}
?>

 </td>
 </tr>
 <tr>
  <td class="one">

<?php echo "<h3> Current Total rain today till 12 am is </h3>";  ?>


 

<?php
// Wind part



$tbl_name="rain"; // Table name 

// Retrieve data from database 
$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
$num=mysql_numrows($result);

?>

 
<?php


// Start looping rows in mysql database.
for ($i=$num+1; $i>$num; $i--)
{
$rows=mysql_fetch_array($result)
?>


<?php 



$timed = $rows['time']; 

echo  round($rows['rain'],1);
echo " mm  __recorded @ ";

include 'date_extract.php';
echo $orgdate;

?>



<?php
// close while loop 
}
?>
</td></tr>

</tbody>
</table>

<!--Div that will hold the pie chart-->
    <div id="chart_div" style="width:400; height:300"></div>



</div>

<div class="col-xs-12 col-sm-3 col-md-3 col-lg-3 sidebar">

<?php include 'sidebar.php'; ?>

</div>


</div>



<?php include 'time.php'; ?>

<?php include 'configclose.php'; ?>
<?php include 'footer.php'; ?>


</div>


</body>
</html>