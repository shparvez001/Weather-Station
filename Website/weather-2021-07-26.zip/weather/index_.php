<?php
$host="localhost";
$username="shparvez_001";
$password="23807161";
$db_name="shparvez_weather";


mysql_connect("$host", "$username", "$password")or die("cannot connect to server");
mysql_select_db("$db_name")or die("cannot select db"); 
?>

<html>

<body>

<form action="<?php $_PHP_SELF ?>" method="POST">

 

Name: <input type="text" name="text" id="text" />


 

<input type="submit" />

</form>

</body>

</html>


<?php

$tbl_name="test"; // Table name 

// Get values from form 
$name=$_POST['text'];

// Insert data into mysql 
$sql="INSERT INTO $tbl_name(text)VALUES('$name')";
$result=mysql_query($sql);

// if successfully insert data into database, displays message "Successful". 
if($result){
echo "Successful";
echo "<BR>";
echo "<a href='shparvez.net'>SHP</a>";
}

else {
echo "ERROR";
}
?> 

<?php 
// close connection 
mysql_close();
?>
