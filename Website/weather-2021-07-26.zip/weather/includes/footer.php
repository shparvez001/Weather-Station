<?php

$mydate=getdate(date("U"));

print "copyright @ $mydate[year]  " ; 
?>
<a title="Mehedhi Hasan Bipul" href="https://www.facebook.com/mehedhi.bipul" target="_blank">Mehedhi Hasan Bipul</a> 	and <a title="Shahadat Hussain Parvez" href="http://shparvez.net" target="_blank">Shahadat Hussain Parvez</a> </p>


<br>


<!-- Histats.com  START  (standard)-->
<script type="text/javascript">document.write(unescape("%3Cscript src=%27http://s10.histats.com/js15.js%27 type=%27text/javascript%27%3E%3C/script%3E"));</script>
<a href="http://www.histats.com" target="_blank" title="Website Statistics" ><script  type="text/javascript" >
try {Histats.start(1,2788169,4,605,110,55,"00011111");
Histats.track_hits();} catch(err){};
</script></a>
<noscript><a href="http://www.histats.com" target="_blank"><img  src="http://sstatic1.histats.com/0.gif?2788169&101" alt="Website Statistics" border="0"></a></noscript>
<!-- Histats.com  END  -->


<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="http://arrow.scrolltotop.com/arrow13.js"></script>
<noscript>Not seeing a <a href="http://www.scrolltotop.com/">Scroll to Top Button</a>? Go to our FAQ page for more info.</noscript>

